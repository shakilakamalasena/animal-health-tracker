package animalhealthtracker;

public class Users {
    public static String[] user = {"Admin Portal", "Veterinary Portal"};
}
